<?php
$fcatalogs_0 = array (
  1 => 
  array (
    'caid' => '1',
    'title' => '友情链接',
    'pid' => '0',
    'vieworder' => '0',
    'chid' => '1',
    'cumode' => '0',
    'allowupdate' => '0',
  ),
  3 => 
  array (
    'caid' => '3',
    'title' => '单页面信息',
    'pid' => '0',
    'vieworder' => '0',
    'chid' => '2',
    'cumode' => '0',
    'allowupdate' => '0',
  ),
) ;
?>