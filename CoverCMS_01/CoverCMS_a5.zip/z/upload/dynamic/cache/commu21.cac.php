<?php
$commu21_0 = array (
  'cuid' => '21',
  'cname' => '回复',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'reply',
  'setting' => 
  array (
    'autocheck' => '1',
    'apmid' => '0',
    'repeat' => '0',
    'repeattime' => 5,
    'nouservote' => '0',
    'repeatvote' => '0',
    'citems' => '',
    'useredits' => '',
  ),
  'func' => '',
  'cutpl' => 'answers.htm',
  'addtpl' => '',
  'sortable' => '1',
  'addable' => '1',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '1',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>