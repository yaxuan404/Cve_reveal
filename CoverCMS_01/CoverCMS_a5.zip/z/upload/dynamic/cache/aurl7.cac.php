<?php
$aurl7_0 = array (
  'auid' => '7',
  'cname' => '答案管理',
  'remark' => '答案管理(系统内置)',
  'uclass' => 'answers',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '8',
  'url' => '?entry=answers&action=answersedit&nauid=7',
  'setting' => 
  array (
    'checked' => '-1',
    'cuids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>