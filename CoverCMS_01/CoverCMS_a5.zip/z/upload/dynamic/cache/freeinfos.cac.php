<?php
$freeinfos_0 = array (
  1 => 
  array (
    'fid' => '1',
    'sid' => '0',
    'cname' => '关于我们',
    'tplname' => 'single_page.htm',
    'arcurl' => '',
  ),
) ;
?>