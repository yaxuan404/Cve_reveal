<?php
$caid_87_0 = array (
  'cnid' => '87',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=87',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '87',
  'cnlevel' => '1',
  'ineedstatic' => '1521626730',
  'lneedstatic' => '1521626730',
  'bkneedstatic' => '1521626730',
) ;
?>