<?php
$caid_62_0 = array (
  'cnid' => '62',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=62',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '62',
  'cnlevel' => '1',
  'ineedstatic' => '1521626151',
  'lneedstatic' => '1521626151',
  'bkneedstatic' => '1521626151',
) ;
?>