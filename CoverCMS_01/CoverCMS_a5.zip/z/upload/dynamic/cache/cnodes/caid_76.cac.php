<?php
$caid_76_0 = array (
  'cnid' => '76',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=76',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '76',
  'cnlevel' => '1',
  'ineedstatic' => '1521626456',
  'lneedstatic' => '1521626456',
  'bkneedstatic' => '1521626456',
) ;
?>