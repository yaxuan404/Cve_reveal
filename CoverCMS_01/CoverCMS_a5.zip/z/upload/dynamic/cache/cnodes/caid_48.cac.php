<?php
$caid_48_0 = array (
  'cnid' => '48',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=48',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '48',
  'cnlevel' => '1',
  'ineedstatic' => '1521625906',
  'lneedstatic' => '1521625906',
  'bkneedstatic' => '1521625906',
) ;
?>