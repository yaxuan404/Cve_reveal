<?php
$caid_57_0 = array (
  'cnid' => '57',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=57',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '57',
  'cnlevel' => '1',
  'ineedstatic' => '1521626051',
  'lneedstatic' => '1521626051',
  'bkneedstatic' => '1521626051',
) ;
?>