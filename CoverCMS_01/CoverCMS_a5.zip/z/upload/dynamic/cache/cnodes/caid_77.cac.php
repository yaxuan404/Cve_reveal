<?php
$caid_77_0 = array (
  'cnid' => '77',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=77',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '77',
  'cnlevel' => '1',
  'ineedstatic' => '1521626466',
  'lneedstatic' => '1521626466',
  'bkneedstatic' => '1521626466',
) ;
?>