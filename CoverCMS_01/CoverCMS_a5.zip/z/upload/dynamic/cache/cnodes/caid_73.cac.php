<?php
$caid_73_0 = array (
  'cnid' => '73',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=73',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '73',
  'cnlevel' => '1',
  'ineedstatic' => '1521626365',
  'lneedstatic' => '1521626365',
  'bkneedstatic' => '1521626365',
) ;
?>