<?php
$caid_85_0 = array (
  'cnid' => '85',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=85',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '85',
  'cnlevel' => '1',
  'ineedstatic' => '1521626709',
  'lneedstatic' => '1521626709',
  'bkneedstatic' => '1521626709',
) ;
?>