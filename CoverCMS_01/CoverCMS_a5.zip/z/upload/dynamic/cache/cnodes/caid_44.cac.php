<?php
$caid_44_0 = array (
  'cnid' => '44',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=44',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '44',
  'cnlevel' => '1',
  'ineedstatic' => '1521616181',
  'lneedstatic' => '1521616181',
  'bkneedstatic' => '1521616181',
) ;
?>