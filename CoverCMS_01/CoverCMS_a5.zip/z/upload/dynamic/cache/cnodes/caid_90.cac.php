<?php
$caid_90_0 = array (
  'cnid' => '90',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=90',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '90',
  'cnlevel' => '1',
  'ineedstatic' => '1521628494',
  'lneedstatic' => '1521628494',
  'bkneedstatic' => '1521628494',
) ;
?>