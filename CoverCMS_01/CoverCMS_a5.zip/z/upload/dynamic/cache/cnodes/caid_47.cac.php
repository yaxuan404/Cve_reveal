<?php
$caid_47_0 = array (
  'cnid' => '47',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=47',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '47',
  'cnlevel' => '1',
  'ineedstatic' => '1521625825',
  'lneedstatic' => '1521625825',
  'bkneedstatic' => '1521625825',
) ;
?>