<?php
$caid_59_0 = array (
  'cnid' => '59',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=59',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '59',
  'cnlevel' => '1',
  'ineedstatic' => '1521626074',
  'lneedstatic' => '1521626074',
  'bkneedstatic' => '1521626074',
) ;
?>