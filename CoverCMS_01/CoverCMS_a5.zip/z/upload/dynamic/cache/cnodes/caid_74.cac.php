<?php
$caid_74_0 = array (
  'cnid' => '74',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=74',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '74',
  'cnlevel' => '1',
  'ineedstatic' => '1521626382',
  'lneedstatic' => '1521626382',
  'bkneedstatic' => '1521626382',
) ;
?>