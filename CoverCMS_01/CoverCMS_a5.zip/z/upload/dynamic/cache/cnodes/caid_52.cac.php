<?php
$caid_52_0 = array (
  'cnid' => '52',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=52',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '52',
  'cnlevel' => '1',
  'ineedstatic' => '1521625980',
  'lneedstatic' => '1521625980',
  'bkneedstatic' => '1521625980',
) ;
?>