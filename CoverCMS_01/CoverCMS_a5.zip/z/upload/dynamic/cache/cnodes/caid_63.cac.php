<?php
$caid_63_0 = array (
  'cnid' => '63',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=63',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '63',
  'cnlevel' => '1',
  'ineedstatic' => '1521626161',
  'lneedstatic' => '1521626161',
  'bkneedstatic' => '1521626161',
) ;
?>