<?php
$caid_66_0 = array (
  'cnid' => '66',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=66',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '66',
  'cnlevel' => '1',
  'ineedstatic' => '1521626204',
  'lneedstatic' => '1521626204',
  'bkneedstatic' => '1521626204',
) ;
?>