<?php
$caid_79_0 = array (
  'cnid' => '79',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=79',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '79',
  'cnlevel' => '1',
  'ineedstatic' => '1521626518',
  'lneedstatic' => '1521626518',
  'bkneedstatic' => '1521626518',
) ;
?>