<?php
$caid_89_0 = array (
  'cnid' => '89',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=89',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '89',
  'cnlevel' => '1',
  'ineedstatic' => '1521626769',
  'lneedstatic' => '1521626769',
  'bkneedstatic' => '1521626769',
) ;
?>