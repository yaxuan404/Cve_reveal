<?php
$caid_71_0 = array (
  'cnid' => '71',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=71',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '71',
  'cnlevel' => '1',
  'ineedstatic' => '1521626345',
  'lneedstatic' => '1521626345',
  'bkneedstatic' => '1521626345',
) ;
?>