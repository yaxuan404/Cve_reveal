<?php
$caid_75_0 = array (
  'cnid' => '75',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=75',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '75',
  'cnlevel' => '1',
  'ineedstatic' => '1521626424',
  'lneedstatic' => '1521626424',
  'bkneedstatic' => '1521626424',
) ;
?>