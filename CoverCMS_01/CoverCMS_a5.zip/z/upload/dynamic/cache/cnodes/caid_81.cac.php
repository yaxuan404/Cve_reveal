<?php
$caid_81_0 = array (
  'cnid' => '81',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=81',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '81',
  'cnlevel' => '1',
  'ineedstatic' => '1521626544',
  'lneedstatic' => '1521626544',
  'bkneedstatic' => '1521626544',
) ;
?>