<?php
$caid_46_0 = array (
  'cnid' => '46',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=46',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '46',
  'cnlevel' => '1',
  'ineedstatic' => '1521625810',
  'lneedstatic' => '1521625810',
  'bkneedstatic' => '1521625810',
) ;
?>