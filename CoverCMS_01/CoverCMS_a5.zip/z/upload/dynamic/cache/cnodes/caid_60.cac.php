<?php
$caid_60_0 = array (
  'cnid' => '60',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=60',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '60',
  'cnlevel' => '1',
  'ineedstatic' => '1521626084',
  'lneedstatic' => '1521626084',
  'bkneedstatic' => '1521626084',
) ;
?>