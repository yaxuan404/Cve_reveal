<?php
$caid_61_0 = array (
  'cnid' => '61',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=61',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '61',
  'cnlevel' => '1',
  'ineedstatic' => '1521626098',
  'lneedstatic' => '1521626098',
  'bkneedstatic' => '1521626098',
) ;
?>