<?php
$caid_84_0 = array (
  'cnid' => '84',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=84',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '84',
  'cnlevel' => '1',
  'ineedstatic' => '1521626683',
  'lneedstatic' => '1521626683',
  'bkneedstatic' => '1521626683',
) ;
?>