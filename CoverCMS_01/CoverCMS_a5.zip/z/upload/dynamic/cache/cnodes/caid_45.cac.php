<?php
$caid_45_0 = array (
  'cnid' => '45',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=45',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '45',
  'cnlevel' => '1',
  'ineedstatic' => '1521625770',
  'lneedstatic' => '1521625770',
  'bkneedstatic' => '1521625770',
) ;
?>