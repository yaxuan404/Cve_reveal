<?php
$caid_83_0 = array (
  'cnid' => '83',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=83',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '83',
  'cnlevel' => '1',
  'ineedstatic' => '1521626655',
  'lneedstatic' => '1521626655',
  'bkneedstatic' => '1521626655',
) ;
?>