<?php
$caid_72_0 = array (
  'cnid' => '72',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=72',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '72',
  'cnlevel' => '1',
  'ineedstatic' => '1521626357',
  'lneedstatic' => '1521626357',
  'bkneedstatic' => '1521626357',
) ;
?>