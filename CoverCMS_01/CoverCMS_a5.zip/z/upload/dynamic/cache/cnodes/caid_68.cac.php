<?php
$caid_68_0 = array (
  'cnid' => '68',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=68',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '68',
  'cnlevel' => '1',
  'ineedstatic' => '1521626232',
  'lneedstatic' => '1521626232',
  'bkneedstatic' => '1521626232',
) ;
?>