<?php
$caid_50_0 = array (
  'cnid' => '50',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=50',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '50',
  'cnlevel' => '1',
  'ineedstatic' => '1521625946',
  'lneedstatic' => '1521625946',
  'bkneedstatic' => '1521625946',
) ;
?>