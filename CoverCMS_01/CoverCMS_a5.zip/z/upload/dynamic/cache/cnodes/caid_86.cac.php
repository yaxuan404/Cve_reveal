<?php
$caid_86_0 = array (
  'cnid' => '86',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=86',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '86',
  'cnlevel' => '1',
  'ineedstatic' => '1521626718',
  'lneedstatic' => '1521626718',
  'bkneedstatic' => '1521626718',
) ;
?>