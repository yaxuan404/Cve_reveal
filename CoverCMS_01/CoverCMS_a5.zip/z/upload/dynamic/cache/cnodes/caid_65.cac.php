<?php
$caid_65_0 = array (
  'cnid' => '65',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=65',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '65',
  'cnlevel' => '1',
  'ineedstatic' => '1521626186',
  'lneedstatic' => '1521626186',
  'bkneedstatic' => '1521626186',
) ;
?>