<?php
$caid_82_0 = array (
  'cnid' => '82',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=82',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '82',
  'cnlevel' => '1',
  'ineedstatic' => '1521626553',
  'lneedstatic' => '1521626553',
  'bkneedstatic' => '1521626553',
) ;
?>