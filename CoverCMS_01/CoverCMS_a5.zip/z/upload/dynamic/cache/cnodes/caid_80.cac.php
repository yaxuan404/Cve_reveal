<?php
$caid_80_0 = array (
  'cnid' => '80',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=80',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '80',
  'cnlevel' => '1',
  'ineedstatic' => '1521626533',
  'lneedstatic' => '1521626533',
  'bkneedstatic' => '1521626533',
) ;
?>