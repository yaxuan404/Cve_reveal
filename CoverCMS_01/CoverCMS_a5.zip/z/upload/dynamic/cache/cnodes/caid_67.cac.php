<?php
$caid_67_0 = array (
  'cnid' => '67',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=67',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '67',
  'cnlevel' => '1',
  'ineedstatic' => '1521626215',
  'lneedstatic' => '1521626215',
  'bkneedstatic' => '1521626215',
) ;
?>