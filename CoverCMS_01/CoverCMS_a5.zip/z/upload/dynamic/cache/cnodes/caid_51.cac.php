<?php
$caid_51_0 = array (
  'cnid' => '51',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=51',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '51',
  'cnlevel' => '1',
  'ineedstatic' => '1521625960',
  'lneedstatic' => '1521625960',
  'bkneedstatic' => '1521625960',
) ;
?>