<?php
$caid_58_0 = array (
  'cnid' => '58',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=58',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '58',
  'cnlevel' => '1',
  'ineedstatic' => '1521626065',
  'lneedstatic' => '1521626065',
  'bkneedstatic' => '1521626065',
) ;
?>