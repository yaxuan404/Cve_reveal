<?php
$caid_70_0 = array (
  'cnid' => '70',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=70',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '70',
  'cnlevel' => '1',
  'ineedstatic' => '1521626322',
  'lneedstatic' => '1521626322',
  'bkneedstatic' => '1521626322',
) ;
?>