<?php
$caid_54_0 = array (
  'cnid' => '54',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=54',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '54',
  'cnlevel' => '1',
  'ineedstatic' => '1521626002',
  'lneedstatic' => '1521626002',
  'bkneedstatic' => '1521626002',
) ;
?>