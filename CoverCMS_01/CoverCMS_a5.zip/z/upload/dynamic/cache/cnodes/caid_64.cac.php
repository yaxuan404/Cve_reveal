<?php
$caid_64_0 = array (
  'cnid' => '64',
  'sid' => '0',
  'alias' => '',
  'appurl' => '',
  'ename' => 'caid=64',
  'inconfig' => '1',
  'indexurl' => '',
  'cncids' => '',
  'listurl' => '',
  'bkurl' => '',
  'indextpl' => 'common_idx.htm',
  'listtpl' => 'common_lst.htm',
  'bktpl' => '',
  'mainline' => 'ca',
  'caid' => '64',
  'cnlevel' => '1',
  'ineedstatic' => '1521626176',
  'lneedstatic' => '1521626176',
  'bkneedstatic' => '1521626176',
) ;
?>