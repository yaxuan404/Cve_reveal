<?php
$fchannels_0 = array (
  1 => 
  array (
    'chid' => '1',
    'cname' => '友情链接',
  ),
  2 => 
  array (
    'chid' => '2',
    'cname' => '单页面信息',
  ),
) ;
?>