<?php
$inmurl5_0 = array (
  'imuid' => '5',
  'cname' => '添加',
  'remark' => '合辑内添加新文档',
  'uclass' => 'inadd',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => 'addpre.php?nimuid=5&aid=',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>