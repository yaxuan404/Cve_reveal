<?php
$inurl6_0 = array (
  'iuid' => '6',
  'cname' => '购买',
  'remark' => '购买购买购买购买',
  'uclass' => 'purchases',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '9',
  'url' => '?entry=inarchive&action=purchases&niuid=6&aid=',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>