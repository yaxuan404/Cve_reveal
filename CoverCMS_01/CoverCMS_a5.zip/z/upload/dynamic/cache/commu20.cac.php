<?php
$commu20_0 = array (
  'cuid' => '20',
  'cname' => '报价',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'offer',
  'setting' => 
  array (
    'apmid' => '0',
    'autocheck' => '1',
    'vdays' => 10,
    'purchase' => '0',
    'nouservote' => '1',
    'repeatvote' => '1',
    'average' => '1',
    'ptable' => 'main',
    'pename' => 'oprice',
    'citems' => '',
    'useredits' => '',
  ),
  'func' => '',
  'cutpl' => 'answers.htm',
  'addtpl' => '',
  'sortable' => '1',
  'addable' => '1',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '1',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>