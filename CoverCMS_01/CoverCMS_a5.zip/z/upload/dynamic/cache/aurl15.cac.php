<?php
$aurl15_0 = array (
  'auid' => '15',
  'cname' => '会员评论',
  'remark' => '会员评论',
  'uclass' => 'mcomments',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '18',
  'url' => '?entry=mcomments&action=mcommentsedit&nauid=15',
  'setting' => 
  array (
    'checked' => '-1',
    'cuids' => '',
    'mchids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>