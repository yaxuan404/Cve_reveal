<?php
$bfields_0 = array (
) ;
?>