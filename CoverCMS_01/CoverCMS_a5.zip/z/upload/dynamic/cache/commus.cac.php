<?php
$commus_0 = array (
  1 => 
  array (
    'cuid' => '1',
    'cname' => '顶/踩',
    'available' => '1',
    'cclass' => 'praise',
    'sortable' => '0',
    'ch' => '0',
  ),
  2 => 
  array (
    'cuid' => '2',
    'cname' => '评分',
    'available' => '1',
    'cclass' => 'score',
    'sortable' => '0',
    'ch' => '0',
  ),
  3 => 
  array (
    'cuid' => '3',
    'cname' => '举报',
    'available' => '1',
    'cclass' => 'report',
    'sortable' => '0',
    'ch' => '1',
  ),
  4 => 
  array (
    'cuid' => '4',
    'cname' => '收藏',
    'available' => '1',
    'cclass' => 'favorite',
    'sortable' => '0',
    'ch' => '0',
  ),
  5 => 
  array (
    'cuid' => '5',
    'cname' => '评论',
    'available' => '1',
    'cclass' => 'comment',
    'sortable' => '1',
    'ch' => '1',
  ),
  6 => 
  array (
    'cuid' => '6',
    'cname' => '答疑',
    'available' => '1',
    'cclass' => 'answer',
    'sortable' => '1',
    'ch' => '1',
  ),
  7 => 
  array (
    'cuid' => '7',
    'cname' => '购物',
    'available' => '1',
    'cclass' => 'purchase',
    'sortable' => '1',
    'ch' => '1',
  ),
  8 => 
  array (
    'cuid' => '8',
    'cname' => '订阅',
    'available' => '1',
    'cclass' => 'subscribe',
    'sortable' => '0',
    'ch' => '0',
  ),
  20 => 
  array (
    'cuid' => '20',
    'cname' => '报价',
    'available' => '1',
    'cclass' => 'offer',
    'sortable' => '1',
    'ch' => '1',
  ),
  21 => 
  array (
    'cuid' => '21',
    'cname' => '回复',
    'available' => '1',
    'cclass' => 'reply',
    'sortable' => '1',
    'ch' => '1',
  ),
) ;
?>