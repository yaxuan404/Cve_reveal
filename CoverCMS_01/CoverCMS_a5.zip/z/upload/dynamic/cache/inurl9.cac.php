<?php
$inurl9_0 = array (
  'iuid' => '9',
  'cname' => '内容',
  'remark' => '辑内文档或合辑的管理',
  'uclass' => 'content',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '4',
  'url' => '?entry=inarchive&action=archives&niuid=9&aid=',
  'setting' => 
  array (
    'sids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>