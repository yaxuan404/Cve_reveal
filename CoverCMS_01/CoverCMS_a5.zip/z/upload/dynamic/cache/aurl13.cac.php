<?php
$aurl13_0 = array (
  'auid' => '13',
  'cname' => '会员管理',
  'remark' => '会员管理',
  'uclass' => 'members',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '13',
  'url' => '?entry=members&action=membersedit&nauid=13',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => 'ugid2',
    'lists' => '',
    'operates' => '',
    'ugids1' => '',
    'ugids2' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>