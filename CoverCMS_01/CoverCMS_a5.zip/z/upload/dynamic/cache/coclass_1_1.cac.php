<?php
$coclass_1_1_0 = array (
  'ccid' => '1',
  'pid' => '0',
  'level' => '0',
  'title' => '首页头条推荐',
  'isframe' => '0',
  'chids' => '1,2,3',
  'mchids' => '',
  'dirname' => 'tj_idx_headline',
  'smallsite' => '',
  'coid' => '1',
  'vieworder' => '0',
  'trueorder' => '0',
  'apmid' => '0',
  'rpmid' => '0',
  'crpmid' => '0',
  'dpmid' => '0',
  'allowsale' => '0',
  'allowfsale' => '0',
  'taxcp' => '0',
  'awardcp' => '0',
  'ftaxcp' => '0',
  'clicks' => '0',
  'archives' => '0',
  'conditions' => 
  array (
  ),
) ;
?>