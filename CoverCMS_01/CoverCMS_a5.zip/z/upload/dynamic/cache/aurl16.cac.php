<?php
$aurl16_0 = array (
  'auid' => '16',
  'cname' => '会员回复',
  'remark' => '会员回复',
  'uclass' => 'mreplys',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '19',
  'url' => '?entry=mreplys&action=mreplysedit&nauid=16',
  'setting' => 
  array (
    'checked' => '-1',
    'cuids' => '',
    'mchids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>