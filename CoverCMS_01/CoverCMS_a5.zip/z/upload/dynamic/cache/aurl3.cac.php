<?php
$aurl3_0 = array (
  'auid' => '3',
  'cname' => '文档管理',
  'remark' => '文档(系统内置)',
  'uclass' => 'archives',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '2',
  'url' => '?entry=archives&action=archivesedit&nauid=3',
  'setting' => 
  array (
    'checked' => '-1',
    'valid' => '-1',
    'chids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
    'iuids' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>