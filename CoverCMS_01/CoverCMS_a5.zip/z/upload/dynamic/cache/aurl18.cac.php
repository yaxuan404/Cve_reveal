<?php
$aurl18_0 = array (
  'auid' => '18',
  'cname' => '类型变更',
  'remark' => '会员类型变更',
  'uclass' => 'mtrans',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '16',
  'url' => '?entry=mtrans&action=mtransedit&nauid=18',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>