<?php
$aurl17_0 = array (
  'auid' => '17',
  'cname' => '会员举报',
  'remark' => '会员举报',
  'uclass' => 'mreports',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '20',
  'url' => '?entry=mreports&action=mreportsedit&nauid=17',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>