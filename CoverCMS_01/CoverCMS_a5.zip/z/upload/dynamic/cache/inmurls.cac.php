<?php
$inmurls_0 = array (
  1 => 
  array (
    'imuid' => '1',
    'cname' => '编辑',
    'remark' => '编辑编辑编辑',
    'uclass' => 'adetail',
    'issys' => '1',
    'url' => '?action=archive&nimuid=1&aid=',
  ),
  2 => 
  array (
    'imuid' => '2',
    'cname' => '归辑',
    'remark' => '归辑归辑归辑',
    'uclass' => 'setalbum',
    'issys' => '1',
    'url' => '?action=setalbum&nimuid=2&aid=',
  ),
  3 => 
  array (
    'imuid' => '3',
    'cname' => '内容',
    'remark' => '合辑内所有内容的管理',
    'uclass' => 'content',
    'issys' => '1',
    'url' => '?action=inarchives&nimuid=3&aid=',
  ),
  4 => 
  array (
    'imuid' => '4',
    'cname' => '加载',
    'remark' => '加载其它文档到当前合辑',
    'uclass' => 'load',
    'issys' => '1',
    'url' => '?action=loadold&nimuid=4&aid=',
  ),
  5 => 
  array (
    'imuid' => '5',
    'cname' => '添加',
    'remark' => '合辑内添加新文档',
    'uclass' => 'inadd',
    'issys' => '1',
    'url' => 'addpre.php?nimuid=5&aid=',
  ),
  6 => 
  array (
    'imuid' => '6',
    'cname' => '回复',
    'remark' => '当前文档收到所有回复',
    'uclass' => 'replys',
    'issys' => '1',
    'url' => '?action=inreplys&nimuid=6&aid=',
  ),
  7 => 
  array (
    'imuid' => '7',
    'cname' => '答案',
    'remark' => '当前提问的所有答案',
    'uclass' => 'answers',
    'issys' => '1',
    'url' => '?action=inanswers&nimuid=7&aid=',
  ),
) ;
?>