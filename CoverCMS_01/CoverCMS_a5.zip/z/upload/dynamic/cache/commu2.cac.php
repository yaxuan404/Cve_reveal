<?php
$commu2_0 = array (
  'cuid' => '2',
  'cname' => '评分',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'score',
  'setting' => 
  array (
    'apmid' => '0',
    'repeat' => '0',
    'repeattime' => 0,
    'minscore' => 1,
    'maxscore' => 10,
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '0',
  'addable' => '0',
  'ch' => '0',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>