<?php
$grouptypes_0 = array (
  1 => 
  array (
    'gtid' => '1',
    'cname' => '屏蔽组系',
    'issystem' => '1',
    'forbidden' => '1',
    'afunction' => '0',
    'mode' => '1',
    'crid' => '0',
    'mchids' => '',
    'allowance' => '0',
  ),
  2 => 
  array (
    'gtid' => '2',
    'cname' => '管理组系',
    'issystem' => '1',
    'forbidden' => '0',
    'afunction' => '1',
    'mode' => '1',
    'crid' => '0',
    'mchids' => '5',
    'allowance' => '0',
  ),
) ;
?>