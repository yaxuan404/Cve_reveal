<?php
$coclass_1_3_0 = array (
  'ccid' => '3',
  'pid' => '0',
  'level' => '0',
  'title' => '通用今日要闻',
  'isframe' => '0',
  'chids' => '1,2,3',
  'mchids' => '',
  'dirname' => 'tj_common_today_news',
  'smallsite' => '',
  'coid' => '1',
  'vieworder' => '0',
  'trueorder' => '2',
  'apmid' => '0',
  'rpmid' => '0',
  'crpmid' => '0',
  'dpmid' => '0',
  'allowsale' => '0',
  'allowfsale' => '0',
  'taxcp' => '0',
  'awardcp' => '0',
  'ftaxcp' => '0',
  'clicks' => '0',
  'archives' => '0',
  'conditions' => 
  array (
  ),
) ;
?>