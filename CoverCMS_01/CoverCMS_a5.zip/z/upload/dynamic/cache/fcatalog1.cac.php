<?php
$fcatalog1_0 = array (
  'caid' => '1',
  'title' => '友情链接',
  'pid' => '0',
  'vieworder' => '0',
  'chid' => '1',
  'cumode' => '0',
  'culength' => '0',
  'autocheck' => '1',
  'allowupdate' => '0',
  'arctpl' => '',
  'apmid' => '0',
  'rpmid' => '0',
  'nodurat' => '1',
  'ucadd' => '',
  'uaadd' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
) ;
?>