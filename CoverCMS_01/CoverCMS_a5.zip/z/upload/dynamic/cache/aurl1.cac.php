<?php
$aurl1_0 = array (
  'auid' => '1',
  'cname' => '内容发布',
  'remark' => '文档与合辑的发布(系统内置)',
  'uclass' => 'arcadd',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '3',
  'url' => '?entry=addpre&nauid=1',
  'setting' => 
  array (
    'coids' => '',
    'chids' => '',
    'nochids' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>