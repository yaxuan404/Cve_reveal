<?php
$aurl19_0 = array (
  'auid' => '19',
  'cname' => '组变更',
  'remark' => '会员组变更',
  'uclass' => 'utrans',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '17',
  'url' => '?entry=utrans&action=utransedit&nauid=19',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>