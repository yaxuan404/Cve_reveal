<?php
$inmurl2_0 = array (
  'imuid' => '2',
  'cname' => '归辑',
  'remark' => '归辑归辑归辑',
  'uclass' => 'setalbum',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=setalbum&nimuid=2&aid=',
  'setting' => 
  array (
    'chids' => '',
    'sids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>