<?php
$aurl20_0 = array (
  'auid' => '20',
  'cname' => '会员档案',
  'remark' => '会员档案',
  'uclass' => 'marchives',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '15',
  'url' => '?entry=marchives&action=marchivesedit&nauid=20',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>