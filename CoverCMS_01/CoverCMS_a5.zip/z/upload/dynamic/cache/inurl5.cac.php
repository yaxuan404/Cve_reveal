<?php
$inurl5_0 = array (
  'iuid' => '5',
  'cname' => '评论',
  'remark' => '档内评论',
  'uclass' => 'comments',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '6',
  'url' => '?entry=inarchive&action=comments&niuid=5&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>