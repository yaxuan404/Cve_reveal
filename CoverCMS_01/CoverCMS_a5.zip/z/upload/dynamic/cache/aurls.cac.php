<?php
$aurls_0 = array (
  3 => 
  array (
    'auid' => '3',
    'cname' => '文档管理',
    'remark' => '文档(系统内置)',
    'uclass' => 'archives',
    'issys' => '1',
    'url' => '?entry=archives&action=archivesedit&nauid=3',
  ),
  1 => 
  array (
    'auid' => '1',
    'cname' => '内容发布',
    'remark' => '文档与合辑的发布(系统内置)',
    'uclass' => 'arcadd',
    'issys' => '1',
    'url' => '?entry=addpre&nauid=1',
  ),
  10 => 
  array (
    'auid' => '10',
    'cname' => '更新管理',
    'remark' => '更新管理(系统内置)',
    'uclass' => 'arcupdate',
    'issys' => '1',
    'url' => '?entry=archives&action=archivesupdate&nauid=10',
  ),
  4 => 
  array (
    'auid' => '4',
    'cname' => '评论管理',
    'remark' => '评论管理(系统内置)',
    'uclass' => 'comments',
    'issys' => '1',
    'url' => '?entry=comments&action=commentsedit&nauid=4',
  ),
  6 => 
  array (
    'auid' => '6',
    'cname' => '回复管理',
    'remark' => '回复管理(系统内置)',
    'uclass' => 'replys',
    'issys' => '1',
    'url' => '?entry=replys&action=replysedit&nauid=6',
  ),
  5 => 
  array (
    'auid' => '5',
    'cname' => '报价管理',
    'remark' => '报价管理(系统内置)',
    'uclass' => 'offers',
    'issys' => '1',
    'url' => '?entry=offers&action=offersedit&nauid=5',
  ),
  7 => 
  array (
    'auid' => '7',
    'cname' => '答案管理',
    'remark' => '答案管理(系统内置)',
    'uclass' => 'answers',
    'issys' => '1',
    'url' => '?entry=answers&action=answersedit&nauid=7',
  ),
  9 => 
  array (
    'auid' => '9',
    'cname' => '举报管理',
    'remark' => '举报管理(系统内置)',
    'uclass' => 'reports',
    'issys' => '1',
    'url' => '?entry=reports&action=reportsedit&nauid=9',
  ),
  11 => 
  array (
    'auid' => '11',
    'cname' => '信息列表',
    'remark' => '信息列表',
    'uclass' => 'farchives',
    'issys' => '1',
    'url' => '?entry=farchives&action=farchivesedit&nauid=11',
  ),
  12 => 
  array (
    'auid' => '12',
    'cname' => '发布信息',
    'remark' => '发布信息',
    'uclass' => 'farcadd',
    'issys' => '1',
    'url' => '?entry=farchive&action=farchiveadd&nauid=12',
  ),
  13 => 
  array (
    'auid' => '13',
    'cname' => '会员管理',
    'remark' => '会员管理',
    'uclass' => 'members',
    'issys' => '1',
    'url' => '?entry=members&action=membersedit&nauid=13',
  ),
  14 => 
  array (
    'auid' => '14',
    'cname' => '添加会员',
    'remark' => '添加会员',
    'uclass' => 'memadd',
    'issys' => '1',
    'url' => '?entry=memberadd&nauid=14',
  ),
  20 => 
  array (
    'auid' => '20',
    'cname' => '会员档案',
    'remark' => '会员档案',
    'uclass' => 'marchives',
    'issys' => '1',
    'url' => '?entry=marchives&action=marchivesedit&nauid=20',
  ),
  18 => 
  array (
    'auid' => '18',
    'cname' => '类型变更',
    'remark' => '会员类型变更',
    'uclass' => 'mtrans',
    'issys' => '1',
    'url' => '?entry=mtrans&action=mtransedit&nauid=18',
  ),
  19 => 
  array (
    'auid' => '19',
    'cname' => '组变更',
    'remark' => '会员组变更',
    'uclass' => 'utrans',
    'issys' => '1',
    'url' => '?entry=utrans&action=utransedit&nauid=19',
  ),
  15 => 
  array (
    'auid' => '15',
    'cname' => '会员评论',
    'remark' => '会员评论',
    'uclass' => 'mcomments',
    'issys' => '1',
    'url' => '?entry=mcomments&action=mcommentsedit&nauid=15',
  ),
  16 => 
  array (
    'auid' => '16',
    'cname' => '会员回复',
    'remark' => '会员回复',
    'uclass' => 'mreplys',
    'issys' => '1',
    'url' => '?entry=mreplys&action=mreplysedit&nauid=16',
  ),
  17 => 
  array (
    'auid' => '17',
    'cname' => '会员举报',
    'remark' => '会员举报',
    'uclass' => 'mreports',
    'issys' => '1',
    'url' => '?entry=mreports&action=mreportsedit&nauid=17',
  ),
) ;
?>