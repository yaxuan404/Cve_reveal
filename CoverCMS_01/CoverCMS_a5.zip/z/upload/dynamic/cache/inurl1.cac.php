<?php
$inurl1_0 = array (
  'iuid' => '1',
  'cname' => '归辑',
  'remark' => '归辑归辑归辑归辑',
  'uclass' => 'setalbum',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '2',
  'url' => '?entry=inarchive&action=setalbum&niuid=1&aid=',
  'setting' => 
  array (
    'chids' => '',
    'sids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>