<?php
$commu6_0 = array (
  'cuid' => '6',
  'cname' => '答疑',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'answer',
  'setting' => 
  array (
    'apmid' => '1',
    'nouservote' => '0',
    'repeatvote' => '0',
    'minlength' => 10,
    'maxlength' => 1000,
    'vdays' => 10,
    'crid' => '2',
    'mini' => 1,
    'max' => 100,
    'credit' => 2,
  ),
  'func' => '',
  'cutpl' => 'answers.htm',
  'addtpl' => '',
  'sortable' => '1',
  'addable' => '1',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>