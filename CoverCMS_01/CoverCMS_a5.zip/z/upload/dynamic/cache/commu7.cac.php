<?php
$commu7_0 = array (
  'cuid' => '7',
  'cname' => '购物',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'purchase',
  'setting' => 
  array (
    'apmid' => '0',
    'gtmode' => '0',
    'citems' => '',
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '1',
  'addable' => '0',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>