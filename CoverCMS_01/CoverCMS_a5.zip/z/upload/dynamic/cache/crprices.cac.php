<?php
$crprices_0 = array (
) ;
?>