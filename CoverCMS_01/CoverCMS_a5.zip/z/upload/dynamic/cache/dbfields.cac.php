<?php
$dbfields_0 = array (
) ;
?>