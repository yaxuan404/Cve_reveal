<?php
$aurl6_0 = array (
  'auid' => '6',
  'cname' => '回复管理',
  'remark' => '回复管理(系统内置)',
  'uclass' => 'replys',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '6',
  'url' => '?entry=replys&action=replysedit&nauid=6',
  'setting' => 
  array (
    'checked' => '-1',
    'cuids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>