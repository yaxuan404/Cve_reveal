<?php
$cmsinfos_0 = array (
  'dbversion' => '5.7.10-log',
  'dbsize' => '945.41 KB',
  'attachsize' => '1.19 MB',
  'sys_mail' => 'SMTP ( Server: localhost)',
  'serverip' => '::1',
  'servername' => 'localhost',
  'archive' => 
  array (
    'ck' => '20',
    'nock' => '0',
    'm' => '20',
    'w' => '20',
    'd3' => '20',
    'd1' => '20',
  ),
  'comment' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'reply' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'offer' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'answer' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'orders' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'member' => 
  array (
    'ck' => '3',
    'nock' => '0',
    'm' => '3',
    'w' => '2',
    'd3' => '0',
    'd1' => '0',
  ),
  'amember' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'mtran' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'utran' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'mcomment' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'mreply' => 
  array (
    'ck' => '0',
    'nock' => '0',
    'm' => '0',
    'w' => '0',
    'd3' => '0',
    'd1' => '0',
  ),
  'lic_str' => '',
) ;
?>