<?php
$fcatalog3_0 = array (
  'caid' => '3',
  'title' => '单页面信息',
  'pid' => '0',
  'vieworder' => '0',
  'chid' => '2',
  'cumode' => '0',
  'culength' => '0',
  'autocheck' => '1',
  'allowupdate' => '0',
  'arctpl' => 'single_info.htm',
  'apmid' => '0',
  'rpmid' => '0',
  'nodurat' => '1',
  'ucadd' => '',
  'uaadd' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
) ;
?>