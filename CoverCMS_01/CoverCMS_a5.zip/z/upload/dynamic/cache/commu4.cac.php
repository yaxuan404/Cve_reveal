<?php
$commu4_0 = array (
  'cuid' => '4',
  'cname' => '收藏',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'favorite',
  'setting' => 
  array (
    'apmid' => '0',
    'max' => 300,
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '0',
  'addable' => '0',
  'ch' => '0',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>