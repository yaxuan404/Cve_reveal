<?php
$inurl12_0 = array (
  'iuid' => '12',
  'cname' => '举报',
  'remark' => '指定文档的举报信息管理',
  'uclass' => 'reports',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '11',
  'url' => '?entry=inarchive&action=reports&niuid=12&aid=',
  'setting' => 
  array (
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>