<?php
$aurl9_0 = array (
  'auid' => '9',
  'cname' => '举报管理',
  'remark' => '举报管理(系统内置)',
  'uclass' => 'reports',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '10',
  'url' => '?entry=reports&action=reportsedit&nauid=9',
  'setting' => 
  array (
    'cuids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>