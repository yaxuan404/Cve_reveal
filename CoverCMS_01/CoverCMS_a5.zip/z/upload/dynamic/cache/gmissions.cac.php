<?php
$gmissions_0 = array (
  1 => 
  array (
    'cname' => 'vvvvv',
    'gmid' => '1',
  ),
) ;
?>