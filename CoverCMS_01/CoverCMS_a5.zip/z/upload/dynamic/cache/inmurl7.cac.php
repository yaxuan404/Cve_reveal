<?php
$inmurl7_0 = array (
  'imuid' => '7',
  'cname' => '答案',
  'remark' => '当前提问的所有答案',
  'uclass' => 'answers',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=inanswers&nimuid=7&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>