<?php
$inurl3_0 = array (
  'iuid' => '3',
  'cname' => '加载',
  'remark' => '辑内加载文档或合辑',
  'uclass' => 'load',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '5',
  'url' => '?entry=inarchive&action=loadold&niuid=3&aid=',
  'setting' => 
  array (
    'chids' => '',
    'sids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>