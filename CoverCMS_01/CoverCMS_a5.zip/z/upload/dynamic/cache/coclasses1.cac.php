<?php
$coclasses1_0 = array (
  1 => 
  array (
    'ccid' => '1',
    'pid' => '0',
    'level' => '0',
    'title' => '首页头条推荐',
    'isframe' => '0',
    'chids' => '1,2,3',
    'mchids' => '',
    'dirname' => 'tj_idx_headline',
    'vieworder' => '0',
  ),
  2 => 
  array (
    'ccid' => '2',
    'pid' => '0',
    'level' => '0',
    'title' => '通用焦点图推荐',
    'isframe' => '0',
    'chids' => '1,2,3',
    'mchids' => '',
    'dirname' => 'tj_common_focuspic',
    'vieworder' => '0',
  ),
  3 => 
  array (
    'ccid' => '3',
    'pid' => '0',
    'level' => '0',
    'title' => '通用今日要闻',
    'isframe' => '0',
    'chids' => '1,2,3',
    'mchids' => '',
    'dirname' => 'tj_common_today_news',
    'vieworder' => '0',
  ),
) ;
?>