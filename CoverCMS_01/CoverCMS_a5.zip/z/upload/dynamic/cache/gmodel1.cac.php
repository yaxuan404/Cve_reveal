<?php
$gmodel1_0 = array (
  'gmid' => '1',
  'sid' => '0',
  'cname' => 'fff',
  'chid' => '1',
  'atid' => '0',
  'gfields' => 
  array (
  ),
) ;
?>