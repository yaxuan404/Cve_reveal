<?php
$inurl10_0 = array (
  'iuid' => '10',
  'cname' => '报价',
  'remark' => '指定文档的报价信息管理',
  'uclass' => 'offers',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '8',
  'url' => '?entry=inarchive&action=offers&niuid=10&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'valid' => '-1',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>