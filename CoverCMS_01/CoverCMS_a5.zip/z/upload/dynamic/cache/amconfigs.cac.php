<?php
$amconfigs_0 = array (
) ;
?>