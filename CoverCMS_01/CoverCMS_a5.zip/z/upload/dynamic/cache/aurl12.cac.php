<?php
$aurl12_0 = array (
  'auid' => '12',
  'cname' => '发布信息',
  'remark' => '发布信息',
  'uclass' => 'farcadd',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '12',
  'url' => '?entry=farchive&action=farchiveadd&nauid=12',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>