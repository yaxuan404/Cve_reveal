<?php
$commu1_0 = array (
  'cuid' => '1',
  'cname' => '顶/踩',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'praise',
  'setting' => 
  array (
    'apmid' => '0',
    'repeat' => '0',
    'repeattime' => 1,
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '0',
  'addable' => '0',
  'ch' => '0',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>