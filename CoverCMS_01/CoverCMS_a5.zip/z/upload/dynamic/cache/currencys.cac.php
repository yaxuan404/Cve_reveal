<?php
$currencys_0 = array (
) ;
?>