<?php
$inurl11_0 = array (
  'iuid' => '11',
  'cname' => '回复',
  'remark' => '指定文档的回复信息管理',
  'uclass' => 'replys',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '7',
  'url' => '?entry=inarchive&action=replys&niuid=11&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>