<?php
$aurl10_0 = array (
  'auid' => '10',
  'cname' => '更新管理',
  'remark' => '更新管理(系统内置)',
  'uclass' => 'arcupdate',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '4',
  'url' => '?entry=archives&action=archivesupdate&nauid=10',
  'setting' => 
  array (
    'coids' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>