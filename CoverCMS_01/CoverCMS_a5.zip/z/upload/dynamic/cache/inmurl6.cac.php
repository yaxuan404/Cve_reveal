<?php
$inmurl6_0 = array (
  'imuid' => '6',
  'cname' => '回复',
  'remark' => '当前文档收到所有回复',
  'uclass' => 'replys',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=inreplys&nimuid=6&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>