<?php
$aurl14_0 = array (
  'auid' => '14',
  'cname' => '添加会员',
  'remark' => '添加会员',
  'uclass' => 'memadd',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '14',
  'url' => '?entry=memberadd&nauid=14',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>