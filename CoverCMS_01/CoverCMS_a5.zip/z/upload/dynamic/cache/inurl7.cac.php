<?php
$inurl7_0 = array (
  'iuid' => '7',
  'cname' => '答案',
  'remark' => '档内答案',
  'uclass' => 'answers',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '10',
  'url' => '?entry=inarchive&action=answers&niuid=7&aid=',
  'setting' => 
  array (
    'checked' => '-1',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>