<?php
$gmission1_0 = array (
  'gsid' => '1',
  'cname' => 'vvvvv',
  'gmid' => '1',
  'sonid' => '0',
  'pid' => '0',
  'mcharset' => '',
  'timeout' => '5',
  'mcookies' => '',
  'umode' => '0',
  'uurls' => '',
  'uregular' => '',
  'ufromnum' => '1',
  'utonum' => '2',
  'ufrompage' => '0',
  'udesc' => '0',
  'uinclude' => '',
  'uforbid' => '',
  'uregion' => '',
  'uspilit' => '',
  'uurltag' => '',
  'utitletag' => '',
  'uurltag1' => '',
  'uinclude1' => '',
  'uforbid1' => '',
  'uurltag2' => '',
  'uinclude2' => '',
  'uforbid2' => '',
  'mpfield' => '',
  'mpmode' => '0',
  'mptag' => '',
  'mpinclude' => '',
  'mpforbid' => '',
  'fsettings' => 
  array (
  ),
  'dvalues' => 
  array (
  ),
  'sid' => '0',
) ;
?>