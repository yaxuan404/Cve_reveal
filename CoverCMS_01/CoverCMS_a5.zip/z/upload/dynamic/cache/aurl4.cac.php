<?php
$aurl4_0 = array (
  'auid' => '4',
  'cname' => '评论管理',
  'remark' => '评论管理(系统内置)',
  'uclass' => 'comments',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '5',
  'url' => '?entry=comments&action=commentsedit&nauid=4',
  'setting' => 
  array (
    'checked' => '-1',
    'cuids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>