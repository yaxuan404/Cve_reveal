<?php
$inmurl4_0 = array (
  'imuid' => '4',
  'cname' => '加载',
  'remark' => '加载其它文档到当前合辑',
  'uclass' => 'load',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=loadold&nimuid=4&aid=',
  'setting' => 
  array (
    'chids' => '',
    'sids' => '',
    'filters' => '',
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>