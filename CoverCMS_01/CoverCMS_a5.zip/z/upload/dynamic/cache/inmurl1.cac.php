<?php
$inmurl1_0 = array (
  'imuid' => '1',
  'cname' => '编辑',
  'remark' => '编辑编辑编辑',
  'uclass' => 'adetail',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=archive&nimuid=1&aid=',
  'setting' => 
  array (
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>