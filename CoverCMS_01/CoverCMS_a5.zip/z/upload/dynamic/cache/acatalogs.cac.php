<?php
$acatalogs_0 = array (
  43 => 
  array (
    'caid' => '43',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '新闻',
    'dirname' => 'news',
    'isframe' => '1',
  ),
  44 => 
  array (
    'caid' => '44',
    'pid' => '43',
    'sid' => '0',
    'level' => '1',
    'title' => '社会',
    'dirname' => 'society',
    'isframe' => '0',
  ),
  45 => 
  array (
    'caid' => '45',
    'pid' => '43',
    'sid' => '0',
    'level' => '1',
    'title' => '国际',
    'dirname' => 'world',
    'isframe' => '0',
  ),
  46 => 
  array (
    'caid' => '46',
    'pid' => '43',
    'sid' => '0',
    'level' => '1',
    'title' => '民生',
    'dirname' => 'minsheng',
    'isframe' => '0',
  ),
  47 => 
  array (
    'caid' => '47',
    'pid' => '43',
    'sid' => '0',
    'level' => '1',
    'title' => '政事',
    'dirname' => 'gov',
    'isframe' => '0',
  ),
  48 => 
  array (
    'caid' => '48',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '图片',
    'dirname' => 'picture',
    'isframe' => '1',
  ),
  49 => 
  array (
    'caid' => '49',
    'pid' => '48',
    'sid' => '0',
    'level' => '1',
    'title' => '高清',
    'dirname' => 'gaoqing',
    'isframe' => '0',
  ),
  50 => 
  array (
    'caid' => '50',
    'pid' => '48',
    'sid' => '0',
    'level' => '1',
    'title' => '图话',
    'dirname' => 'tuhua',
    'isframe' => '0',
  ),
  51 => 
  array (
    'caid' => '51',
    'pid' => '48',
    'sid' => '0',
    'level' => '1',
    'title' => '活着',
    'dirname' => 'huozhe',
    'isframe' => '0',
  ),
  52 => 
  array (
    'caid' => '52',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '娱乐',
    'dirname' => 'yule',
    'isframe' => '1',
  ),
  53 => 
  array (
    'caid' => '53',
    'pid' => '52',
    'sid' => '0',
    'level' => '1',
    'title' => '明星',
    'dirname' => 'mingxing',
    'isframe' => '0',
  ),
  54 => 
  array (
    'caid' => '54',
    'pid' => '52',
    'sid' => '0',
    'level' => '1',
    'title' => '电影',
    'dirname' => 'movie',
    'isframe' => '0',
  ),
  55 => 
  array (
    'caid' => '55',
    'pid' => '52',
    'sid' => '0',
    'level' => '1',
    'title' => '电视剧',
    'dirname' => 'dianshiju',
    'isframe' => '0',
  ),
  56 => 
  array (
    'caid' => '56',
    'pid' => '52',
    'sid' => '0',
    'level' => '1',
    'title' => '综艺',
    'dirname' => 'zongyi',
    'isframe' => '0',
  ),
  57 => 
  array (
    'caid' => '57',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '科技',
    'dirname' => 'keji',
    'isframe' => '1',
  ),
  61 => 
  array (
    'caid' => '61',
    'pid' => '57',
    'sid' => '0',
    'level' => '1',
    'title' => '探索',
    'dirname' => 'explore',
    'isframe' => '0',
  ),
  60 => 
  array (
    'caid' => '60',
    'pid' => '57',
    'sid' => '0',
    'level' => '1',
    'title' => '手机',
    'dirname' => 'shouji',
    'isframe' => '0',
  ),
  59 => 
  array (
    'caid' => '59',
    'pid' => '57',
    'sid' => '0',
    'level' => '1',
    'title' => '电脑',
    'dirname' => 'diannao',
    'isframe' => '0',
  ),
  58 => 
  array (
    'caid' => '58',
    'pid' => '57',
    'sid' => '0',
    'level' => '1',
    'title' => '数码',
    'dirname' => 'shuma',
    'isframe' => '0',
  ),
  62 => 
  array (
    'caid' => '62',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '教育',
    'dirname' => 'edu',
    'isframe' => '1',
  ),
  63 => 
  array (
    'caid' => '63',
    'pid' => '62',
    'sid' => '0',
    'level' => '1',
    'title' => '出国',
    'dirname' => 'chuguo',
    'isframe' => '0',
  ),
  64 => 
  array (
    'caid' => '64',
    'pid' => '62',
    'sid' => '0',
    'level' => '1',
    'title' => '考研',
    'dirname' => 'kaoyan',
    'isframe' => '0',
  ),
  65 => 
  array (
    'caid' => '65',
    'pid' => '62',
    'sid' => '0',
    'level' => '1',
    'title' => '英语',
    'dirname' => 'yingyu',
    'isframe' => '0',
  ),
  66 => 
  array (
    'caid' => '66',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '视频',
    'dirname' => 'video',
    'isframe' => '1',
  ),
  67 => 
  array (
    'caid' => '67',
    'pid' => '66',
    'sid' => '0',
    'level' => '1',
    'title' => '一线',
    'dirname' => 'yixian',
    'isframe' => '0',
  ),
  68 => 
  array (
    'caid' => '68',
    'pid' => '66',
    'sid' => '0',
    'level' => '1',
    'title' => '专访',
    'dirname' => 'zhuanfang',
    'isframe' => '0',
  ),
  69 => 
  array (
    'caid' => '69',
    'pid' => '66',
    'sid' => '0',
    'level' => '1',
    'title' => '舆情',
    'dirname' => 'yuqing',
    'isframe' => '0',
  ),
  90 => 
  array (
    'caid' => '90',
    'pid' => '66',
    'sid' => '0',
    'level' => '1',
    'title' => '人物',
    'dirname' => 'renwu',
    'isframe' => '0',
  ),
  70 => 
  array (
    'caid' => '70',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '时尚',
    'dirname' => 'fashion',
    'isframe' => '1',
  ),
  71 => 
  array (
    'caid' => '71',
    'pid' => '70',
    'sid' => '0',
    'level' => '1',
    'title' => '服饰',
    'dirname' => 'fushi',
    'isframe' => '0',
  ),
  72 => 
  array (
    'caid' => '72',
    'pid' => '70',
    'sid' => '0',
    'level' => '1',
    'title' => '美容',
    'dirname' => 'meirong',
    'isframe' => '0',
  ),
  73 => 
  array (
    'caid' => '73',
    'pid' => '70',
    'sid' => '0',
    'level' => '1',
    'title' => '偶像',
    'dirname' => 'ouxiang',
    'isframe' => '0',
  ),
  74 => 
  array (
    'caid' => '74',
    'pid' => '70',
    'sid' => '0',
    'level' => '1',
    'title' => '视觉',
    'dirname' => 'shijue',
    'isframe' => '0',
  ),
  75 => 
  array (
    'caid' => '75',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '文化',
    'dirname' => 'culture',
    'isframe' => '1',
  ),
  76 => 
  array (
    'caid' => '76',
    'pid' => '75',
    'sid' => '0',
    'level' => '1',
    'title' => '艺术',
    'dirname' => 'yishu',
    'isframe' => '0',
  ),
  77 => 
  array (
    'caid' => '77',
    'pid' => '75',
    'sid' => '0',
    'level' => '1',
    'title' => '思想',
    'dirname' => 'sixiang',
    'isframe' => '0',
  ),
  78 => 
  array (
    'caid' => '78',
    'pid' => '75',
    'sid' => '0',
    'level' => '1',
    'title' => '眼界',
    'dirname' => 'yanjie',
    'isframe' => '0',
  ),
  79 => 
  array (
    'caid' => '79',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '财经',
    'dirname' => 'caijing',
    'isframe' => '1',
  ),
  80 => 
  array (
    'caid' => '80',
    'pid' => '79',
    'sid' => '0',
    'level' => '1',
    'title' => '金融',
    'dirname' => 'jinrong',
    'isframe' => '0',
  ),
  81 => 
  array (
    'caid' => '81',
    'pid' => '79',
    'sid' => '0',
    'level' => '1',
    'title' => '证券',
    'dirname' => 'zhengquan',
    'isframe' => '0',
  ),
  82 => 
  array (
    'caid' => '82',
    'pid' => '79',
    'sid' => '0',
    'level' => '1',
    'title' => '新三板',
    'dirname' => 'xinsanban',
    'isframe' => '0',
  ),
  83 => 
  array (
    'caid' => '83',
    'pid' => '0',
    'sid' => '0',
    'level' => '0',
    'title' => '历史',
    'dirname' => 'lishi',
    'isframe' => '1',
  ),
  84 => 
  array (
    'caid' => '84',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '观世变',
    'dirname' => 'guanshibian',
    'isframe' => '0',
  ),
  85 => 
  array (
    'caid' => '85',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '近代史',
    'dirname' => 'jindaishi',
    'isframe' => '0',
  ),
  86 => 
  array (
    'caid' => '86',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '重读',
    'dirname' => 'chongdu',
    'isframe' => '0',
  ),
  87 => 
  array (
    'caid' => '87',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '现代史',
    'dirname' => 'xiandaishi',
    'isframe' => '0',
  ),
  88 => 
  array (
    'caid' => '88',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '古代史',
    'dirname' => 'gudaishi',
    'isframe' => '0',
  ),
  89 => 
  array (
    'caid' => '89',
    'pid' => '83',
    'sid' => '0',
    'level' => '1',
    'title' => '世界史',
    'dirname' => 'shijieshi',
    'isframe' => '0',
  ),
) ;
?>