<?php
$badwords_0 = array (
  'wreplace' => 
  array (
    0 => '*v*',
  ),
  'wsearch' => 
  array (
    0 => '/妈的/i',
  ),
) ;
?>