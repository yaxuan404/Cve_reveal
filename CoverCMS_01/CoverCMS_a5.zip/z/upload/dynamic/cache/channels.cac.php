<?php
$channels_0 = array (
  1 => 
  array (
    'chid' => '1',
    'cname' => '文章',
    'available' => '1',
    'userforbidadd' => '0',
    'isalbum' => '0',
    'cuid' => '0',
    'baidu' => '0',
    'fulltxt' => 'content',
    'allowance' => '0',
  ),
  2 => 
  array (
    'chid' => '2',
    'cname' => '组图',
    'available' => '1',
    'userforbidadd' => '0',
    'isalbum' => '0',
    'cuid' => '0',
    'baidu' => '0',
    'fulltxt' => 'content',
    'allowance' => '0',
  ),
  3 => 
  array (
    'chid' => '3',
    'cname' => '视频',
    'available' => '1',
    'userforbidadd' => '0',
    'isalbum' => '0',
    'cuid' => '0',
    'baidu' => '',
    'fulltxt' => '',
    'allowance' => '0',
  ),
) ;
?>