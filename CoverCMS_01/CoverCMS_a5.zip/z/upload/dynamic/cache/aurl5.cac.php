<?php
$aurl5_0 = array (
  'auid' => '5',
  'cname' => '报价管理',
  'remark' => '报价管理(系统内置)',
  'uclass' => 'offers',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '7',
  'url' => '?entry=offers&action=offersedit&nauid=5',
  'setting' => 
  array (
    'checked' => '-1',
    'valid' => '-1',
    'cuids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>