<?php
$inurl8_0 = array (
  'iuid' => '8',
  'cname' => '添加',
  'remark' => '辑内不指定类型的添加',
  'uclass' => 'inadd',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '1',
  'url' => '?entry=addpre&niuid=8&aid=',
  'setting' => 
  array (
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>