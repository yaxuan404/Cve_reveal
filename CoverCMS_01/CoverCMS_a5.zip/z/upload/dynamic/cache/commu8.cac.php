<?php
$commu8_0 = array (
  'cuid' => '8',
  'cname' => '订阅',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'subscribe',
  'setting' => 
  array (
    'apmid' => '0',
    'autoarc' => '1',
    'autoatm' => '1',
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '0',
  'addable' => '0',
  'ch' => '0',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>