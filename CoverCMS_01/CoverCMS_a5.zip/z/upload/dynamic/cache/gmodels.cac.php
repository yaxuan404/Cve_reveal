<?php
$gmodels_0 = array (
  1 => 
  array (
    'cname' => 'fff',
    'chid' => '1',
  ),
) ;
?>