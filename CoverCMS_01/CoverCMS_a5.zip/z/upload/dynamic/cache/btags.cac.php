<?php
$btags_0 = array (
  'cms_icpno' => '<a href="http://www.miibeian.gov.cn" target="_blank">沪ICP备09026950号</a>',
  'cmslogo' => 'http://p0.ifengimg.com/a/2017/1030/bcd70b413953679size8_w330_h65.jpg',
  'bazscert' => '备案证书bazs.cert文件',
  'copyright' => 'Copyright © 2015-2018 <a href="http://www.svipplus.com/" target="_blank">SVIPLUS.COM</a> All Rights Reserved.',
  'hostname' => '网站主站名称',
  'hosturl' => 'http://localhost',
  'cmsname' => 'CoverCMS系统网站',
  'cmsurl' => '/ins/',
  'cmstitle' => '开源,免费,PHP网站管理系统',
  'cmskeyword' => '网站管理系统 cms 开源 免费 整站系统 文章管理系统 自定义模型 多重分类cms 问吧管理系统 网上商店系统',
  'cmsdescription' => 'CoverCMS具有独特的设计理念,完全由用户自定义文档模型,多重X多层的自由类目系统,用户自定义多重系统合辑,自定义模型的网站附属信息发布系统,完全界面化的模板设计系统,类目内允许多种文档模型混排',
  'cmsindex' => NULL,
  'cms_abs' => 'http://localhost/ins/',
  'cms_rel' => '/ins/',
  'mcharset' => 'utf-8',
  'version' => '1.16',
  'tplurl' => 'http://localhost/ins/template/default/',
  'cms_counter' => '<script type="text/javascript" src="http://localhost/ins/counter.php"></script>',
) ;
?>