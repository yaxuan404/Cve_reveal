<?php
$ffields2_0 = array (
  'subject' => 
  array (
    'cname' => '信息标题',
    'issystem' => '1',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
  'content' => 
  array (
    'cname' => '内容',
    'issystem' => '0',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'htmltext',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
) ;
?>