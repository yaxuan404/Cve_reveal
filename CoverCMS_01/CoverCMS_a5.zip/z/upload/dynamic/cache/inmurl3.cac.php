<?php
$inmurl3_0 = array (
  'imuid' => '3',
  'cname' => '内容',
  'remark' => '合辑内所有内容的管理',
  'uclass' => 'content',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?action=inarchives&nimuid=3&aid=',
  'setting' => 
  array (
    'sids' => '',
    'chids' => '',
    'filters' => '',
    'lists' => 'catalog,channel,check,incheck,adddate,view,edit',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>