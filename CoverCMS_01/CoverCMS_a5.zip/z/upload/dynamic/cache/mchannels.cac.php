<?php
$mchannels_0 = array (
  1 => 
  array (
    'mchid' => '1',
    'cname' => '基本会员',
    'available' => '0',
    'issystem' => '1',
    'userforbidadd' => '0',
    'autocheck' => '1',
    'reply' => '0',
    'comment' => '0',
    'srhtpl' => '',
    'addtpl' => 'register.htm',
    'acoids' => '',
    'ccoids' => '',
    'additems' => '',
    'useredits' => '',
  ),
) ;
?>