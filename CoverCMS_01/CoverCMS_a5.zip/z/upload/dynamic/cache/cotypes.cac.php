<?php
$cotypes_0 = array (
  1 => 
  array (
    'coid' => '1',
    'cname' => '推荐类系',
    'vieworder' => '0',
    'notblank' => '0',
    'sortable' => '0',
    'mainline' => '0',
    'self_reg' => '0',
    'vmode' => '0',
    'permission' => '0',
    'awardcp' => '0',
    'taxcp' => '0',
    'ftaxcp' => '0',
    'sale' => '0',
    'fsale' => '0',
  ),
) ;
?>