<?php
$commu3_0 = array (
  'cuid' => '3',
  'cname' => '举报',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'report',
  'setting' => 
  array (
    'apmid' => '0',
    'repeat' => '0',
    'repeattime' => 0,
    'citems' => '',
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '0',
  'addable' => '1',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>