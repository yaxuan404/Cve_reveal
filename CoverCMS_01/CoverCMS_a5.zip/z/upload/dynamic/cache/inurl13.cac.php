<?php
$inurl13_0 = array (
  'iuid' => '13',
  'cname' => '编辑',
  'remark' => '文档的详情编辑',
  'uclass' => 'adetail',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '0',
  'url' => '?entry=archive&action=archivedetail&niuid=13&aid=',
  'setting' => 
  array (
    'lists' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>