<?php
$aurl11_0 = array (
  'auid' => '11',
  'cname' => '信息列表',
  'remark' => '信息列表',
  'uclass' => 'farchives',
  'issys' => '1',
  'available' => '1',
  'vieworder' => '11',
  'url' => '?entry=farchives&action=farchivesedit&nauid=11',
  'setting' => 
  array (
    'checked' => '-1',
    'valid' => '-1',
    'consult' => '0',
    'filters' => '',
    'lists' => '',
    'operates' => '',
  ),
  'tplname' => '',
  'onlyview' => '0',
  'mtitle' => '',
  'guide' => '',
  'isbk' => '0',
) ;
?>