<?php
$commu5_0 = array (
  'cuid' => '5',
  'cname' => '评论',
  'issystem' => '1',
  'available' => '1',
  'cclass' => 'comment',
  'setting' => 
  array (
    'apmid' => '0',
    'autocheck' => '1',
    'repeat' => '0',
    'repeattime' => 1,
    'nouservote' => '0',
    'repeatvote' => '0',
    'citems' => '',
  ),
  'func' => '',
  'cutpl' => '',
  'addtpl' => '',
  'sortable' => '1',
  'addable' => '1',
  'ch' => '1',
  'isbk' => '0',
  'allowance' => '0',
  'ucadd' => '',
  'ucvote' => '',
  'uadetail' => '',
  'umdetail' => '',
  'usetting' => 
  array (
  ),
  'uconfig' => '',
) ;
?>