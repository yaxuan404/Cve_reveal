<?php
$ffields1_0 = array (
  'subject' => 
  array (
    'cname' => '信息标题',
    'issystem' => '1',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
  'url' => 
  array (
    'cname' => '链接地址',
    'issystem' => '0',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
  'intro' => 
  array (
    'cname' => '网站简介',
    'issystem' => '0',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
  'contactor' => 
  array (
    'cname' => '联系人',
    'issystem' => '0',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
  'email' => 
  array (
    'cname' => '邮箱',
    'issystem' => '0',
    'available' => '1',
    'isfunc' => '0',
    'datatype' => 'text',
    'isadmin' => '0',
    'vieworder' => '0',
    'pmid' => '0',
    'useredit' => '0',
  ),
) ;
?>