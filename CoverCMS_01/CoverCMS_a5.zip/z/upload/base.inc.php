<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpw = 'rootroot';
$dbname = 'dbcovercms';
$pconnect = 0;

$tblprefix = 'cms_';
$dbcharset = '';		// MySQL 字符集, 可选 'gbk', 'big5', 'utf8', 'latin1', 留空为按照系统字符集设定
$mcharset = 'utf-8';		// 系统页面默认字符集, 可选 'gbk', 'big5', 'utf-8'
$cms_version = '1.16';
$lan_version = 'sc';	//简体sc,繁体tc

$ckpre = 'FI3_';
$ckdomain = '';
$ckpath = '/';
//$ckpath = '/';
$adminemail = 'admin@your.com';
$phpviewerror = 0;//是否报告程序出错信息，0-不报告，1-只报告给管理员，2-报告给所有用户
?>