<?php
include_once(M_ROOT . '/include/extract/extract.cls.php');

$ex = new extract_cash();
$ex->showlist();
?>