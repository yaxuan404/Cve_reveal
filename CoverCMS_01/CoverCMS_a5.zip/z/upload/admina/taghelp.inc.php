<?php
(!defined('M_COM') || !defined('M_ADMIN')) && exit('No Permission');
aheader();
a_guide('taghelp');
?>
